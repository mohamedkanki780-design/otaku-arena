/*
 * إعداد Supabase لـ OTAKU ARENA
 * انسخ هذا الملف إلى supabase-config.js ثم ضع بيانات مشروعك.
 * استخدم Project URL و anon/public key فقط داخل تطبيق الويب.
 * ممنوع تمامًا وضع service_role key في التطبيق أو رفعه إلى GitHub.
 */
window.OTAKU_ARENA_SUPABASE = {
  url: "https://YOUR_PROJECT_ID.supabase.co",
  anonKey: "YOUR_SUPABASE_ANON_PUBLIC_KEY"
};
