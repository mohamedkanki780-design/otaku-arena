/* Supabase public client configuration. Never put a service_role/secret key here. */
window.OTAKU_ARENA_SUPABASE = {
  url: "https://qsuaxukmxebbjnygivjq.supabase.co",
  anonKey: "sb_publishable_g8PsJ8zyW3wy1XL3PSbWsw_mYZ6tU4P"
};
